import 'dart:async';

import 'package:flame/camera.dart';
import 'package:flame/components.dart';
import 'package:flame/game.dart';
import 'package:flame_tiled/flame_tiled.dart';
import 'package:nextbigthing/pages/gameover_page.dart';
import 'package:nextbigthing/pages/gameplay_page.dart';
import 'package:nextbigthing/pages/title_page.dart';
import 'components/mario.dart';
import 'constants/globals/globals.dart';

class MarioLite extends FlameGame {
  late RouterComponent router;
  late final CameraComponent cam;

  @override
  FutureOr<void> onLoad() {

     add(
      router = RouterComponent(
        routes: {
          'title': Route(TitlePage.new),
          'gameplay': Route(GameplayPage.new),
          'gameover': Route(GameoverPage.new),
        },
        initialRoute: 'title',
      ),
    );

    return super.onLoad();
  }

}
