import 'numbers.dart';
import 'paths/paths.dart';

class Globals {
  Globals._();

  static const Numbers numbers = Numbers();
  static const Paths paths = Paths();
}
