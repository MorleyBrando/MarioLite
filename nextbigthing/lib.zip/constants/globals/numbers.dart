class Numbers {
  const Numbers();

  final double tileSize = 16;
  final double marioSpriteStepTime = 0.075;
}