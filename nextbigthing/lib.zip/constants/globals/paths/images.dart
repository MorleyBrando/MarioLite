class Images {
  const Images();

  final String marioIdle = "mario_idle.gif";
  final String marioJump = "mario_jump.gif";
  final String marioDead = "mario_dead.gif";
  final List<String> marioWalk = const [
    "mario_1_walk.gif",
    "mario_2_walk.gif",
    "mario_3_walk.gif",
  ];

}