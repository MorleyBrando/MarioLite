class TileMaps {
  const TileMaps();

  final String level1 = 'world_1_1_map.tmx';
}