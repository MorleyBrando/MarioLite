import 'images.dart';
import 'tileMaps.dart';

class Paths {
  const Paths();

  final Images images = const Images();
  final TileMaps tileMaps = const TileMaps();
}
