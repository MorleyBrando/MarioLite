import 'mario_animation_configs.dart';

class AnimationConfigs {
  AnimationConfigs._();

  static MarioAnimationConfigs mario = MarioAnimationConfigs();
}