import 'package:flame/components.dart';
import 'package:flame/sprite.dart';
import '../globals/globals.dart';

class MarioAnimationConfigs {
  Future<SpriteAnimation> idle() async => SpriteAnimation.spriteList(
    [await Sprite.load(Globals.paths.images.marioIdle)],
    stepTime: Globals.numbers.marioSpriteStepTime,
  );

  Future<SpriteAnimation> walking() async => SpriteAnimation.spriteList(
    await Future.wait(
      Globals.paths.images.marioWalk.map((path) => Sprite.load(path)).toList()),
      stepTime: Globals.numbers.marioSpriteStepTime,
  );

  Future<SpriteAnimation> jumping() async => SpriteAnimation.spriteList(
    [await Sprite.load(Globals.paths.images.marioJump)],
    stepTime: Globals.numbers.marioSpriteStepTime,
  );
}