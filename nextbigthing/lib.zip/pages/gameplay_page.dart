import 'dart:async';

import 'package:flame/components.dart';
import 'package:flame_tiled/flame_tiled.dart';
import 'package:nextbigthing/mario_lite.dart';

class GameplayPage extends Component with HasGameRef<MarioLite>{

  late CameraComponent cam;
  final world = World();

  @override
  FutureOr<void> onLoad() async{
    TiledComponent level = await TiledComponent.load('world_1_1_map.tmx', Vector2.all(16));
    world.add(level);

    cam = CameraComponent.withFixedResolution(world: world, width: gameRef.size.x, height: gameRef.size.y);
    cam.viewfinder.anchor = Anchor.topLeft;
    cam.viewfinder.zoom = 1.75;

    addAll([world, cam]);

    return super.onLoad();
  }

}