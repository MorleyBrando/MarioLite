import 'package:flame/components.dart';

class GameoverPage extends Component{}