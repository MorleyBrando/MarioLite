import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flame/flame.dart';
import 'package:nextbigthing/mario_lite.dart';

class TitlePage extends Component with HasGameRef<MarioLite>, TapCallbacks {
  late SpriteComponent background;

  @override
  Future<void> onLoad() async {
    final titleScreen = await Flame.images.load("titlescreen.png");

    background = SpriteComponent();
    background.sprite = Sprite(titleScreen);
    background.size = gameRef.size;

    add(background);
  }

  @override
  void onTapDown(TapDownEvent event) {
    game.router.pushNamed('gameplay');
  }
}
